# Raíz y nervio

App de estudio offline (PWA): inervación muscular, dermatomas, reflejos, plexos, localización y EMG, con repetición espaciada.

## Publicar en GitHub Pages
1. Crea un repositorio y sube todos los archivos de esta carpeta a la raíz.
2. Settings → Pages → Deploy from a branch → `main` / `(root)`.
3. Abre la URL en el móvil una vez con conexión y usa «Añadir a pantalla de inicio».

Después funciona sin conexión. El progreso se guarda en el dispositivo; usa Ajustes → Exportar progreso para hacer copias.
